#include "MovieGUI.h"

MovieGUI::MovieGUI(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
